#include <iostream>
using namespace std;

struct Nut {
    int gia_tri;
    Nut* trai;
    Nut* phai;
    int chieu_cao;
};

int lay_chieu_cao(Nut* n) {
    return (n == NULL) ? 0 : n->chieu_cao;
}

int lay_can_bang(Nut* n) {
    return (n == NULL) ? 0 : lay_chieu_cao(n->trai) - lay_chieu_cao(n->phai);
}

Nut* tao_nut(int gia_tri) {
    Nut* nut_moi = new Nut();
    nut_moi->gia_tri = gia_tri;
    nut_moi->trai = NULL;
    nut_moi->phai = NULL;
    nut_moi->chieu_cao = 1;
    return nut_moi;
}

Nut* quay_phai(Nut* y) {
    Nut* x = y->trai;
    Nut* T2 = x->phai;
    x->phai = y;
    y->trai = T2;
    y->chieu_cao = max(lay_chieu_cao(y->trai), lay_chieu_cao(y->phai)) + 1;
    x->chieu_cao = max(lay_chieu_cao(x->trai), lay_chieu_cao(x->phai)) + 1;
    return x;
}

Nut* quay_trai(Nut* x) {
    Nut* y = x->phai;
    Nut* T2 = y->trai;
    y->trai = x;
    x->phai = T2;
    x->chieu_cao = max(lay_chieu_cao(x->trai), lay_chieu_cao(x->phai)) + 1;
    y->chieu_cao = max(lay_chieu_cao(y->trai), lay_chieu_cao(y->phai)) + 1;
    return y;
}

Nut* them(Nut* nut, int gia_tri) {
    if (nut == NULL) return tao_nut(gia_tri);
    if (gia_tri < nut->gia_tri)
        nut->trai = them(nut->trai, gia_tri);
    else if (gia_tri > nut->gia_tri)
        nut->phai = them(nut->phai, gia_tri);
    else
        return nut;

    nut->chieu_cao = 1 + max(lay_chieu_cao(nut->trai), lay_chieu_cao(nut->phai));
    int can_bang = lay_can_bang(nut);
    
    if (can_bang > 1 && gia_tri < nut->trai->gia_tri) return quay_phai(nut);
    if (can_bang < -1 && gia_tri > nut->phai->gia_tri) return quay_trai(nut);
    if (can_bang > 1 && gia_tri > nut->trai->gia_tri) {
        nut->trai = quay_trai(nut->trai);
        return quay_phai(nut);
    }
    if (can_bang < -1 && gia_tri < nut->phai->gia_tri) {
        nut->phai = quay_phai(nut->phai);
        return quay_trai(nut);
    }
    return nut;
}

Nut* tim_nut_min(Nut* nut) {
    while (nut->trai != NULL)
        nut = nut->trai;
    return nut;
}

Nut* xoa(Nut* goc, int gia_tri) {
    if (goc == NULL) return goc;
    if (gia_tri < goc->gia_tri)
        goc->trai = xoa(goc->trai, gia_tri);
    else if (gia_tri > goc->gia_tri)
        goc->phai = xoa(goc->phai, gia_tri);
    else {
        if ((goc->trai == NULL) || (goc->phai == NULL)) {
            Nut* tam = goc->trai ? goc->trai : goc->phai;
            if (tam == NULL) {
                tam = goc;
                goc = NULL;
            } else
                *goc = *tam;
            delete tam;
        } else {
            Nut* tam = tim_nut_min(goc->phai);
            goc->gia_tri = tam->gia_tri;
            goc->phai = xoa(goc->phai, tam->gia_tri);
        }
    }
    if (goc == NULL) return goc;
    goc->chieu_cao = 1 + max(lay_chieu_cao(goc->trai), lay_chieu_cao(goc->phai));
    int can_bang = lay_can_bang(goc);
    
    if (can_bang > 1 && lay_can_bang(goc->trai) >= 0) return quay_phai(goc);
    if (can_bang > 1 && lay_can_bang(goc->trai) < 0) {
        goc->trai = quay_trai(goc->trai);
        return quay_phai(goc);
    }
    if (can_bang < -1 && lay_can_bang(goc->phai) <= 0) return quay_trai(goc);
    if (can_bang < -1 && lay_can_bang(goc->phai) > 0) {
        goc->phai = quay_phai(goc->phai);
        return quay_trai(goc);
    }
    return goc;
}

void duyet_LNR(Nut* goc) {
    if (goc != NULL) {
        duyet_LNR(goc->trai);
        cout << goc->gia_tri << " ";
        duyet_LNR(goc->phai);
    }
}

int main() {
    Nut* goc = NULL;
    goc = them(goc, 10);
    goc = them(goc, 20);
    goc = them(goc, 30);
    goc = them(goc, 40);
    goc = them(goc, 50);
    goc = them(goc, 25);
    cout << "Cay AVL sau khi them: ";
    duyet_LNR(goc);
    cout << endl;
    goc = xoa(goc, 30);
    cout << "Cay AVL sau khi xoa 30: ";
    duyet_LNR(goc);
    cout << endl;
    return 0;
}
