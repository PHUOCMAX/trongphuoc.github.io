void InsertFirst(Node* &pHead, int x) {
  Node* p = CreateNode(x);
  p->next = pHead;
  pHead = p;
}
