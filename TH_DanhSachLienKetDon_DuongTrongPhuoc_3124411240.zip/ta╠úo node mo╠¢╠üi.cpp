Node* CreateNode(int X) {
  Node* p = new Node;
  p->info = X;
  p->next = NULL;
  return p;
}
