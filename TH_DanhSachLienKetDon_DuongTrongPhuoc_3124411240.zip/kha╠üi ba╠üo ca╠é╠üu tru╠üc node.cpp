typedef struct node {
  int info;
  struct node* next;
} Node;

Node* pHead = NULL;  // Khởi tạo danh sách rỗng
