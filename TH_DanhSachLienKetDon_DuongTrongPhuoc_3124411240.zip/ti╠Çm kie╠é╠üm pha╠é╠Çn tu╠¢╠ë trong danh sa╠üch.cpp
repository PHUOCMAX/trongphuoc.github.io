Node* Find(Node* pHead, int x) {
  Node* p = pHead;
  while (p != NULL) {
    if (p->info == x) return p;
    p = p->next;
  }
  return NULL;
}