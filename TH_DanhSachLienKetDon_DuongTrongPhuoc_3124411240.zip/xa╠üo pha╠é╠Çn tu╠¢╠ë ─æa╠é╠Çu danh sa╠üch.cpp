void DeleteFirst(Node* &pHead) {
  if (pHead != NULL) {
    Node* p = pHead;
    pHead = pHead->next;
    delete p;
  }
}
