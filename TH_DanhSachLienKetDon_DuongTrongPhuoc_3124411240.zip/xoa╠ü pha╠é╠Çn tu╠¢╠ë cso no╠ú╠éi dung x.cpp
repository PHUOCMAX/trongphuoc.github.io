void Remove(Node* &pHead, int x) {
  Node* p = pHead, *tp = NULL;
  while (p != NULL && p->info != x) {
    tp = p;
    p = p->next;
  }
  if (p != NULL) {
    if (tp == NULL) 
      pHead = p->next;
    else 
      tp->next = p->next;
    delete p;
  }
}
