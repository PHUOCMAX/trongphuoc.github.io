void InsertAfter(Node* p, int x) {
  if (p != NULL) {
    Node* q = CreateNode(x);
    q->next = p->next;
    p->next = q;
  }
}
