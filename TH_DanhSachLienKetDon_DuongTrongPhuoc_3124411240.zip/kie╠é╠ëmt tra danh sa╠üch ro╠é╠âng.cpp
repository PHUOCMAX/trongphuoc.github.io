bool IsEmpty(Node* pHead) {
  return (pHead == NULL);
}
