void SelectionSort(Node* &pHead) {
  for (Node* p = pHead; p->next != NULL; p = p->next) {
    Node* pmin = p;
    for (Node* q = p->next; q != NULL; q = q->next) {
      if (q->info < pmin->info) 
        pmin = q;
    }
    int temp = p->info;
    p->info = pmin->info;
    pmin->info = temp;
  }
}
