void Init(Node* &pHead) {
  pHead = NULL;
}