void ShowList(Node* pHead) {
  for (Node* p = pHead; p != NULL; p = p->next)
    printf("%d \t", p->info);
}
