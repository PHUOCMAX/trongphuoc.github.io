#include <iostream>

using namespace std;

// Cấu trúc danh sách liên kết số nguyên
struct Node {
    int data;
    Node* next;
};

// Hàm khởi tạo danh sách rỗng
void Init(Node*& head) {
    head = NULL;
}

// Hàm thêm phần tử vào đầu danh sách
void InsertFirst(Node*& head, int x) {
    Node* p = new Node;
    p->data = x;
    p->next = head;
    head = p;
}

// Hàm hiển thị danh sách
void ShowList(Node* head) {
    Node* p = head;
    while (p != NULL) {
        cout << p->data << " ";
        p = p->next;
    }
    cout << endl;
}

// Hàm xóa phần tử có giá trị x trong danh sách
void Remove(Node*& head, int x) {
    Node* p = head, *prev = NULL;
    while (p != NULL && p->data != x) {
        prev = p;
        p = p->next;
    }
    if (p != NULL) {
        if (prev == NULL) head = p->next;
        else prev->next = p->next;
        delete p;
    }
}

// Hàm thêm danh sách thứ hai vào danh sách thứ nhất
void MergeLists(Node*& list1, Node*& list2) {
    if (list1 == NULL) {
        list1 = list2;
    } else {
        Node* p = list1;
        while (p->next != NULL) {
            p = p->next;
        }
        p->next = list2;
    }
    list2 = NULL; // Tránh trùng lặp danh sách
}

// Chương trình chính
int main() {
    Node* list1 = NULL, *list2 = NULL;
    Init(list1);
    Init(list2);
    
    cout << "Nhập 10 số nguyên vào danh sách 1:\n";
    for (int i = 0; i < 10; i++) {
        int x;
        cin >> x;
        InsertFirst(list1, x);
    }
    
    cout << "Danh sách 1: ";
    ShowList(list1);
    
    int k;
    cout << "Nhập số cần xóa trong danh sách 1: ";
    cin >> k;
    Remove(list1, k);
    
    cout << "Danh sách 1 sau khi xóa: ";
    ShowList(list1);
    
    cout << "Nhập 5 số nguyên vào danh sách 2:\n";
    for (int i = 0; i < 5; i++) {
        int x;
        cin >> x;
        InsertFirst(list2, x);
    }
    
    cout << "Danh sách 2: ";
    ShowList(list2);
    
    // Hợp nhất danh sách 2 vào danh sách 1
    MergeLists(list1, list2);
    
    cout << "Danh sách 1 sau khi hợp nhất: ";
    ShowList(list1);
    
    return 0;
}
