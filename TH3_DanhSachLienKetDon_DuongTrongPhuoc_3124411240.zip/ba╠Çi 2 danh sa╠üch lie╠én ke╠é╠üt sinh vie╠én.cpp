#include <iostream>
#include <string>

using namespace std;

// Cấu trúc danh sách liên kết sinh viên
struct SinhVien {
    string hoTen;
    string diaChi;
    string lop;
    int khoa;
    SinhVien* next;
};

// Hàm khởi tạo danh sách sinh viên
void Init(SinhVien*& head) {
    head = NULL;
}

// Hàm thêm sinh viên vào danh sách
void InsertFirst(SinhVien*& head, SinhVien sv) {
    SinhVien* p = new SinhVien(sv);
    p->next = head;
    head = p;
}

// Hàm hiển thị danh sách sinh viên
void ShowList(SinhVien* head) {
    SinhVien* p = head;
    while (p != NULL) {
        cout << p->hoTen << " - " << p->diaChi << " - " << p->lop << " - " << p->khoa << endl;
        p = p->next;
    }
}

// Hàm xóa sinh viên theo tên
void RemoveByName(SinhVien*& head, string name) {
    SinhVien *p = head, *prev = NULL;
    while (p != NULL && p->hoTen != name) {
        prev = p;
        p = p->next;
    }
    if (p != NULL) {
        if (prev == NULL) head = p->next;
        else prev->next = p->next;
        delete p;
    }
}

// Hàm xóa sinh viên theo địa chỉ
void RemoveByAddress(SinhVien*& head, string address) {
    SinhVien *p = head, *prev = NULL;
    while (p != NULL && p->diaChi != address) {
        prev = p;
        p = p->next;
    }
    if (p != NULL) {
        if (prev == NULL) head = p->next;
        else prev->next = p->next;
        delete p;
    }
}

// Hàm sắp xếp danh sách sinh viên theo khóa học (Selection Sort)
void SelectionSort(SinhVien*& head) {
    for (SinhVien* p = head; p != NULL && p->next != NULL; p = p->next) {
        SinhVien* min = p;
        for (SinhVien* q = p->next; q != NULL; q = q->next) {
            if (q->khoa < min->khoa) {
                min = q;
            }
        }
        swap(p->hoTen, min->hoTen);
        swap(p->diaChi, min->diaChi);
        swap(p->lop, min->lop);
        swap(p->khoa, min->khoa);
    }
}

// Chương trình xử lý danh sách sinh viên
int main() {
    SinhVien* listSV = NULL;
    Init(listSV);
    
    cout << "Nhập 10 sinh viên:\n";
    for (int i = 0; i < 10; i++) {
        SinhVien sv;
        cout << "Nhập họ tên: "; cin.ignore(); getline(cin, sv.hoTen);
        cout << "Nhập địa chỉ: "; getline(cin, sv.diaChi);
        cout << "Nhập lớp: "; getline(cin, sv.lop);
        cout << "Nhập khóa: "; cin >> sv.khoa;
        InsertFirst(listSV, sv);
    }
    
    cout << "Danh sách sinh viên:\n";
    ShowList(listSV);
    
    // Xóa sinh viên theo tên và địa chỉ
    RemoveByName(listSV, "Nguyen Van Teo");
    RemoveByAddress(listSV, "Nguyen Van Cu");
    
    // Thêm sinh viên mới
    SinhVien newSV = {"Tran Thi Mo", "25 Hong Bang", "TT0901", 2009, NULL};
    InsertFirst(listSV, newSV);
    
    // Sắp xếp danh sách theo khóa
    SelectionSort(listSV);
    
    cout << "Danh sách sinh viên sau khi cập nhật:\n";
    ShowList(listSV);
    
    return 0;
}