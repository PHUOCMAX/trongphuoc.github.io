#include <stdio.h>
#include <stdlib.h>

// Cấu trúc một nút trong cây nhị phân tìm kiếm
typedef struct TreeNode {
    int val;
    struct TreeNode* left;
    struct TreeNode* right;
} TreeNode;

// Hàm tạo một nút mới
TreeNode* createNode(int val) {
    TreeNode* newNode = (TreeNode*)malloc(sizeof(TreeNode));
    newNode->val = val;
    newNode->left = newNode->right = NULL;
    return newNode;
}

// Hàm chèn một nút vào cây nhị phân tìm kiếm
TreeNode* insert(TreeNode* root, int val) {
    if (root == NULL) return createNode(val);
    if (val < root->val)
        root->left = insert(root->left, val);
    else
        root->right = insert(root->right, val);
    return root;
}

// Hàm duyệt hậu tự (Postorder - LRN)
void postorderTraversal(TreeNode* root) {
    if (root == NULL) return;
    postorderTraversal(root->left);
    postorderTraversal(root->right);
    printf("%d ", root->val);
}

// Hàm tìm phần tử nhỏ nhất trong cây
TreeNode* findMin(TreeNode* root) {
    if (root == NULL) return NULL;
    TreeNode* current = root;
    while (current->left != NULL)
        current = current->left;
    return current;
}

// Hàm tìm phần tử lớn nhất trong cây
TreeNode* findMax(TreeNode* root) {
    if (root == NULL) return NULL;
    TreeNode* current = root;
    while (current->right != NULL)
        current = current->right;
    return current;
}

int main() {
    // Xây dựng cây với thứ tự chèn: 10, 5, 15, 3, 9, 12, 18, 7, 20
    TreeNode* root = NULL;
    int values[] = {10, 5, 15, 3, 9, 12, 18, 7, 20};
    int n = sizeof(values) / sizeof(values[0]);
    for (int i = 0; i < n; i++) {
        root = insert(root, values[i]);
    }

    // In kết quả duyệt hậu tự
    printf("Duyệt hậu tự (Postorder LRN): ");
    postorderTraversal(root);
    printf("\n");
    
    // Tìm phần tử nhỏ nhất và lớn nhất
    TreeNode* minNode = findMin(root);
    TreeNode* maxNode = findMax(root);
    
    printf("Phần tử nhỏ nhất: %d\n", minNode->val);
    printf("Phần tử lớn nhất: %d\n", maxNode->val);
    
    return 0;
}