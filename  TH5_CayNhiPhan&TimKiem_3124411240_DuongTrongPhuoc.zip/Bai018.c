#include <iostream>
using namespace std;

// Định nghĩa cấu trúc của một nút trong cây BST
struct BST_NODE {
    int Key;                 // Giá trị khóa
    BST_NODE *Left, *Right;  // Con trái và con phải
};

typedef BST_NODE* TREE;

// Hàm tìm phần tử thay thế (phần tử tận cùng bên trái của nhánh phải)
void SearchStandFor(TREE &p, TREE &q) {
    if (q->Left)  // Nếu nút q có con trái thì tiếp tục đi sang trái
        SearchStandFor(p, q->Left);
    else {
        p->Key = q->Key;  // Gán giá trị của q cho p
        p = q;            // p trỏ đến q để chuẩn bị xóa
        q = q->Right;     // Nếu q có con phải, cập nhật q thành con phải
    }
}

// Hàm chèn một phần tử vào cây BST
void InsertNode(TREE &root, int x) {
    if (root == NULL) {
        root = new BST_NODE{x, NULL, NULL};
        return;
    }
    if (x < root->Key)
        InsertNode(root->Left, x);
    else
        InsertNode(root->Right, x);
}

// Hàm xóa một nút khỏi BST
void DeleteNode(TREE &root, int x) {
    if (root == NULL) return;
    
    if (x < root->Key) DeleteNode(root->Left, x);
    else if (x > root->Key) DeleteNode(root->Right, x);
    else { // root->Key == x
        TREE temp = root;
        if (root->Left == NULL) root = root->Right;
        else if (root->Right == NULL) root = root->Left;
        else {
            SearchStandFor(temp, root->Right);  // Tìm phần tử thay thế
        }
        delete temp;
    }
}

// Duyệt cây theo thứ tự NLR để in giá trị
void NLR(TREE root) {
    if (root != NULL) {
        cout << root->Key << " ";
        NLR(root->Left);
        NLR(root->Right);
    }
}

// Hàm khởi tạo cây
void Init(TREE &t) {
    t = NULL;
}

// Hàm tạo một nút mới
BST_NODE* GetNode(int x) {
    BST_NODE* p = new BST_NODE;
    if (p == NULL) return NULL;
    p->Key = x;
    p->Left = p->Right = NULL;
    return p;
}

// Hàm chèn một phần tử vào cây
int InsertNodeBST(TREE &t, int x) {
    if (t) {
        if (t->Key == x) return 0;
        if (t->Key < x) return InsertNodeBST(t->Right, x);
        return InsertNodeBST(t->Left, x);
    }
    t = GetNode(x);
    if (t == NULL) return -1;
    return 1;
}

// Hàm tạo cây từ mảng
int TaoCay(TREE &t, int a[], int n) {
    Init(t);
    for (int i = 0; i < n; i++) {
        if (InsertNodeBST(t, a[i]) == -1)
            return 0;
    }
    return 1;
}

// Hàm duyệt cây theo LNR để đưa phần tử về mảng
void LNR(TREE t, int a[], int &n) {
    if (t == NULL) return;
    LNR(t->Left, a, n);
    a[n] = t->Key;
    n++;
    LNR(t->Right, a, n);
}

int main() {
    TREE root = NULL;
    int arr[] = {64, 37, 78, 10, 57, 69, 82, 6, 67, 93};
    int n = sizeof(arr) / sizeof(arr[0]);
    
    // Tạo cây từ mảng
    TaoCay(root, arr, n);
    
    // Chuyển cây về lại mảng
    int sortedArr[10], index = 0;
    LNR(root, sortedArr, index);
    
    // In mảng đã sắp xếp
    cout << "Mang sau khi sap xep: ";
    for (int i = 0; i < index; i++) {
        cout << sortedArr[i] << " ";
    }
    cout << endl;
    
    return 0;
}
