#include <stdio.h>
#include <stdlib.h>

// Định nghĩa cấu trúc cây nhị phân
struct node {
    float info;
    struct node *pLeft, *pRight;
};
typedef struct node NODE;
typedef NODE* TREE;

// Hàm tạo một nút mới
NODE* CreateNode(float x) {
    NODE* p = (NODE*)malloc(sizeof(NODE));
    if (p == NULL) {
        printf("Không đủ bộ nhớ!\n");
        exit(1);
    }
    p->info = x;
    p->pLeft = p->pRight = NULL;
    return p;
}

// Hàm chèn một giá trị vào BST
void Insert(TREE *t, float x) {
    if (*t == NULL) {
        *t = CreateNode(x);
        return;
    }
    if (x < (*t)->info)
        Insert(&((*t)->pLeft), x);
    else
        Insert(&((*t)->pRight), x);
}

// Hàm xuất cây xuống tập tin theo thứ tự NLR (trước - trái - phải)
void SaveTree(FILE *fp, TREE t) {
    if (t == NULL) {
        float marker = -1;  // Đánh dấu NULL
        fwrite(&marker, sizeof(float), 1, fp);
        return;
    }
    fwrite(&t->info, sizeof(float), 1, fp);
    SaveTree(fp, t->pLeft);
    SaveTree(fp, t->pRight);
}

// Hàm lưu cây vào tệp tin
int SaveToFile(char *filename, TREE t) {
    FILE *fp = fopen(filename, "wb");
    if (fp == NULL) return 0;
    SaveTree(fp, t);
    fclose(fp);
    return 1;
}

// Hàm đọc lại cây từ tập tin
void LoadTree(FILE *fp, TREE *t) {
    float value;
    if (fread(&value, sizeof(float), 1, fp) == 0 || value == -1)
        return;
    *t = CreateNode(value);
    LoadTree(fp, &((*t)->pLeft));
    LoadTree(fp, &((*t)->pRight));
}

// Hàm đọc cây từ tập tin
int LoadFromFile(char *filename, TREE *t) {
    FILE *fp = fopen(filename, "rb");
    if (fp == NULL) return 0;
    LoadTree(fp, t);
    fclose(fp);
    return 1;
}

// Hàm duyệt cây theo thứ tự LNR (trái - trước - phải) để kiểm tra
void InOrder(TREE t) {
    if (t == NULL) return;
    InOrder(t->pLeft);
    printf("%.2f ", t->info);
    InOrder(t->pRight);
}

// Chương trình chính
int main() {
    TREE t = NULL;
    float values[] = {10.5, 5.2, 15.8, 3.1, 7.4, 12.6, 18.3};
    int n = sizeof(values) / sizeof(values[0]);
    
    // Tạo cây
    for (int i = 0; i < n; i++)
        Insert(&t, values[i]);
    
    printf("Cây trước khi lưu: ");
    InOrder(t);
    printf("\n");
    
    // Lưu cây vào tập tin
    SaveToFile("data.out", t);
    
    // Xóa cây cũ
    t = NULL;
    
    // Đọc lại cây từ tập tin
    LoadFromFile("data.out", &t);
    
    printf("Cây sau khi đọc từ file: ");
    InOrder(t);
    printf("\n");
    
    return 0;
}
