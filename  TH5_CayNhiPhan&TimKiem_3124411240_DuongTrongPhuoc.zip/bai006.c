#include <stdio.h>
#include <stdlib.h>

// Cấu trúc một nút trong cây nhị phân tìm kiếm
typedef struct TreeNode {
    int val;
    struct TreeNode* left;
    struct TreeNode* right;
} TreeNode;

// Hàm tạo một nút mới
TreeNode* createNode(int val) {
    TreeNode* newNode = (TreeNode*)malloc(sizeof(TreeNode));
    newNode->val = val;
    newNode->left = newNode->right = NULL;
    return newNode;
}

// Hàm chèn một nút vào cây nhị phân tìm kiếm
TreeNode* insert(TreeNode* root, int val) {
    if (root == NULL) return createNode(val);
    if (val < root->val)
        root->left = insert(root->left, val);
    else
        root->right = insert(root->right, val);
    return root;
}

// Hàm đếm số nút trong cây
int countNodes(TreeNode* root) {
    if (root == NULL) return 0;
    return 1 + countNodes(root->left) + countNodes(root->right);
}

// Hàm tính tổng giá trị các nút trong cây
int sumNodes(TreeNode* root) {
    if (root == NULL) return 0;
    return root->val + sumNodes(root->left) + sumNodes(root->right);
}

int main() {
    // Xây dựng cây với thứ tự chèn: 10, 5, 15, 3, 9, 12, 18, 7, 20
    TreeNode* root = NULL;
    int values[] = {10, 5, 15, 3, 9, 12, 18, 7, 20};
    int n = sizeof(values) / sizeof(values[0]);
    for (int i = 0; i < n; i++) {
        root = insert(root, values[i]);
    }
    
    // Đếm số nút trong cây
    int nodeCount = countNodes(root);
    printf("Số lượng nút trong cây: %d\n", nodeCount);
    
    // Tính tổng giá trị các nút trong cây
    int nodeSum = sumNodes(root);
    printf("Tổng giá trị các nút trong cây: %d\n", nodeSum);
    
    return 0;
}
