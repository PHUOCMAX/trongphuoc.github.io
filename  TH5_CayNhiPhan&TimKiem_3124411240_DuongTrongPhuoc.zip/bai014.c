#include <stdio.h>
#include <stdlib.h>

// Cấu trúc cây nhị phân tìm kiếm (BST)
struct nodetree {
    int info;
    struct nodetree* pLeft;
    struct nodetree* pRight;
};
typedef struct nodetree NODETREE;
typedef NODETREE* TREE;

// Cấu trúc danh sách liên kết đơn
struct nodelist {
    int info;
    struct nodelist* pNext;
};
typedef struct nodelist NODELIST;

struct list {
    NODELIST* pHead;
    NODELIST* pTail;
};
typedef struct list LIST;

// Hàm khởi tạo danh sách liên kết
void Init(LIST &l) {
    l.pHead = l.pTail = NULL;
}

// Hàm tạo một nút mới trong danh sách
NODELIST* GetNode(int x) {
    NODELIST* p = new NODELIST;
    if (p == NULL) return NULL;
    p->info = x;
    p->pNext = NULL;
    return p;
}

// Hàm thêm nút vào cuối danh sách
void AddTail(LIST &l, NODELIST* p) {
    if (l.pHead == NULL)
        l.pHead = l.pTail = p;
    else {
        l.pTail->pNext = p;
        l.pTail = p;
    }
}

// Hàm chèn một giá trị vào cây BST
void Insert(TREE &t, int x) {
    if (t == NULL) {
        t = (TREE)malloc(sizeof(NODETREE));
        t->info = x;
        t->pLeft = t->pRight = NULL;
        return;
    }
    if (x < t->info)
        Insert(t->pLeft, x);
    else
        Insert(t->pRight, x);
}

// Hàm duyệt cây theo thứ tự giảm dần (RNL) và thêm vào danh sách
void RNL(TREE Root, LIST &l) {
    if (Root == NULL) return;
    
    RNL(Root->pRight, l); // Duyệt cây con phải trước
    NODELIST* p = GetNode(Root->info);
    if (p != NULL) 
        AddTail(l, p);
    RNL(Root->pLeft, l); // Duyệt cây con trái sau
}

// Hàm xây dựng danh sách từ cây BST
void BuildList(TREE Root, LIST &l) {
    Init(l);
    RNL(Root, l);
}

// Hàm in danh sách liên kết
void PrintList(LIST l) {
    NODELIST* p = l.pHead;
    while (p != NULL) {
        printf("%d -> ", p->info);
        p = p->pNext;
    }
    printf("NULL\n");
}

// Chương trình chính để kiểm tra
int main() {
    TREE root = NULL;
    
    // Chèn các phần tử vào BST
    Insert(root, 50);
    Insert(root, 30);
    Insert(root, 70);
    Insert(root, 20);
    Insert(root, 40);
    Insert(root, 60);
    Insert(root, 80);

    LIST l;
    BuildList(root, l);

    printf("Danh sach lien ket (giam dan):\n");
    PrintList(l);

    return 0;
}
