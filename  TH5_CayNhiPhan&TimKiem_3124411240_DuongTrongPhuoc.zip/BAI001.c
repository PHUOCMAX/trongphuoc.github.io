#include <stdio.h>
#include <stdlib.h>

typedef struct TreeNode {
    int val;
    struct TreeNode* left;
    struct TreeNode* right;
} TreeNode;

TreeNode* createNode(int val) {
    TreeNode* newNode = (TreeNode*)malloc(sizeof(TreeNode));
    newNode->val = val;
    newNode->left = newNode->right = NULL;
    return newNode;
}

void sum_and_count(TreeNode* root, int* sum, int* count) {
    if (!root) return;
    *sum += root->val;
    (*count)++;
    sum_and_count(root->left, sum, count);
    sum_and_count(root->right, sum, count);
}

double avg_all_nodes(TreeNode* root) {
    int sum = 0, count = 0;
    sum_and_count(root, &sum, &count);
    return count > 0 ? (double)sum / count : 0;
}

void sum_and_count_positive(TreeNode* root, int* sum, int* count) {
    if (!root) return;
    if (root->val > 0) {
        *sum += root->val;
        (*count)++;
    }
    sum_and_count_positive(root->left, sum, count);
    sum_and_count_positive(root->right, sum, count);
}

double avg_positive_nodes(TreeNode* root) {
    int sum = 0, count = 0;
    sum_and_count_positive(root, &sum, &count);
    return count > 0 ? (double)sum / count : 0;
}

void sum_and_count_negative(TreeNode* root, int* sum, int* count) {
    if (!root) return;
    if (root->val < 0) {
        *sum += root->val;
        (*count)++;
    }
    sum_and_count_negative(root->left, sum, count);
    sum_and_count_negative(root->right, sum, count);
}

double avg_negative_nodes(TreeNode* root) {
    int sum = 0, count = 0;
    sum_and_count_negative(root, &sum, &count);
    return count > 0 ? (double)sum / count : 0;
}

double ratio_positive_negative(TreeNode* root) {
    int sum_positive = 0, count_positive = 0;
    int sum_negative = 0, count_negative = 0;
    
    sum_and_count_positive(root, &sum_positive, &count_positive);
    sum_and_count_negative(root, &sum_negative, &count_negative);
    
    return sum_negative != 0 ? (double)sum_positive / abs(sum_negative) : 0;
}
