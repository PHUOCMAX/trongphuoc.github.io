#include <stdio.h>
#include <stdlib.h>

// Định nghĩa cấu trúc cây nhị phân tìm kiếm
struct node {
    int info;
    struct node *pLeft, *pRight;
};
typedef struct node NODE;
typedef NODE* TREE;

// Hàm tạo một nút mới
NODE* CreateNode(int x) {
    NODE* newNode = (NODE*)malloc(sizeof(NODE));
    newNode->info = x;
    newNode->pLeft = newNode->pRight = NULL;
    return newNode;
}

// Hàm chèn một phần tử vào cây BST
void InsertNode(TREE *t, int x) {
    if (*t == NULL) {
        *t = CreateNode(x);
        return;
    }
    if (x < (*t)->info)
        InsertNode(&((*t)->pLeft), x);
    else if (x > (*t)->info)
        InsertNode(&((*t)->pRight), x);
}

// Hàm duyệt cây theo phương pháp RNL (Right - Node - Left)
void RNL(TREE t) {
    if (t == NULL) return;
    RNL(t->pRight); // Duyệt cây con phải trước
    printf("%d ", t->info); // Xuất giá trị tại nút gốc
    RNL(t->pLeft);  // Duyệt cây con trái sau
}

int main() {
    TREE t = NULL;
    int values[] = {10, 5, 15, 2, 7, 12, 20}; // Các giá trị thêm vào cây
    int n = sizeof(values) / sizeof(values[0]);

    // Xây dựng cây BST
    for (int i = 0; i < n; i++) {
        InsertNode(&t, values[i]);
    }

    printf("Cac gia tri trong cay theo thu tu giam dan (RNL):\n");
    RNL(t); // Xuất các giá trị theo thứ tự giảm dần
    
    return 0;
}