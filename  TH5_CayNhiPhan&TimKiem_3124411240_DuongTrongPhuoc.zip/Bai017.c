#include <iostream>
using namespace std;

// Định nghĩa cấu trúc của một nút trong cây BST
struct BST_NODE {
    int Key;                 // Giá trị khóa
    BST_NODE *Left, *Right;  // Con trái và con phải
};

typedef BST_NODE* TREE;

// Hàm tìm phần tử thay thế (phần tử tận cùng bên trái của nhánh phải)
void SearchStandFor(TREE &p, TREE &q) {
    if (q->Left)  // Nếu nút q có con trái thì tiếp tục đi sang trái
        SearchStandFor(p, q->Left);
    else {
        p->Key = q->Key;  // Gán giá trị của q cho p
        p = q;            // p trỏ đến q để chuẩn bị xóa
        q = q->Right;     // Nếu q có con phải, cập nhật q thành con phải
    }
}

// Hàm chèn một phần tử vào cây BST
void InsertNode(TREE &root, int x) {
    if (root == NULL) {
        root = new BST_NODE{x, NULL, NULL};
        return;
    }
    if (x < root->Key)
        InsertNode(root->Left, x);
    else
        InsertNode(root->Right, x);
}

// Hàm xóa một nút khỏi BST
void DeleteNode(TREE &root, int x) {
    if (root == NULL) return;
    
    if (x < root->Key) DeleteNode(root->Left, x);
    else if (x > root->Key) DeleteNode(root->Right, x);
    else { // root->Key == x
        TREE temp = root;
        if (root->Left == NULL) root = root->Right;
        else if (root->Right == NULL) root = root->Left;
        else {
            SearchStandFor(temp, root->Right);  // Tìm phần tử thay thế
        }
        delete temp;
    }
}

// Duyệt cây theo thứ tự NLR để in giá trị
void NLR(TREE root) {
    if (root != NULL) {
        cout << root->Key << " ";
        NLR(root->Left);
        NLR(root->Right);
    }
}

int main() {
    TREE root = NULL;
    InsertNode(root, 50);
    InsertNode(root, 30);
    InsertNode(root, 70);
    InsertNode(root, 20);
    InsertNode(root, 40);
    InsertNode(root, 60);
    InsertNode(root, 80);
    
    cout << "Cay truoc khi xoa: ";
    NLR(root);
    cout << endl;
    
    DeleteNode(root, 50);  // Xóa nút 50 (có hai con)
    
    cout << "Cay sau khi xoa: ";
    NLR(root);
    cout << endl;
    
    return 0;
}