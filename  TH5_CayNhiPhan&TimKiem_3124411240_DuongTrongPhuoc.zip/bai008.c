#include <stdio.h>
#include <stdlib.h>

// Định nghĩa cấu trúc cây nhị phân
struct node {
    float info;
    struct node *pLeft;
    struct node *pRight;
};
typedef struct node NODE;
typedef NODE *TREE;

// Hàm khởi tạo cây
void Init(TREE *t) {
    *t = NULL;
}

// Hàm thêm một nút vào cây nhị phân tìm kiếm
void InsertNode(TREE *t, float x) {
    if (*t == NULL) {
        NODE *newNode = (NODE *)malloc(sizeof(NODE));
        newNode->info = x;
        newNode->pLeft = NULL;
        newNode->pRight = NULL;
        *t = newNode;
    } else {
        if (x < (*t)->info)
            InsertNode(&((*t)->pLeft), x);
        else
            InsertNode(&((*t)->pRight), x);
    }
}

// Hàm duyệt cây theo thứ tự LNR và ghi vào tệp nhị phân
void LNR(TREE t, FILE *fp) {
    if (t == NULL)
        return;
    LNR(t->pLeft, fp);
    fwrite(&t->info, sizeof(float), 1, fp);
    LNR(t->pRight, fp);
}

// Hàm xuất cây ra tệp nhị phân
int Xuat(char *filename, TREE t) {
    FILE *fp = fopen(filename, "wb"); // Mở tệp để ghi nhị phân
    if (fp == NULL)
        return 0; // Lỗi mở tệp
    LNR(t, fp);
    fclose(fp);
    return 1; // Thành công
}

// Hàm kiểm tra nội dung tệp nhị phân
void DocFile(char *filename) {
    FILE *fp = fopen(filename, "rb");
    if (fp == NULL) {
        printf("Không thể mở tệp!\n");
        return;
    }
    float value;
    printf("Dữ liệu trong tệp: ");
    while (fread(&value, sizeof(float), 1, fp)) {
        printf("%.2f ", value);
    }
    printf("\n");
    fclose(fp);
}

int main() {
    TREE t;
    Init(&t);
    
    // Thêm các nút vào cây
    InsertNode(&t, 10.5);
    InsertNode(&t, 5.2);
    InsertNode(&t, 15.8);
    InsertNode(&t, 3.1);
    InsertNode(&t, 7.7);
    InsertNode(&t, 12.4);
    InsertNode(&t, 20.9);
    
    // Xuất cây vào tệp nhị phân
    if (Xuat("data.out", t)) {
        printf("Ghi thành công vào data.out!\n");
    } else {
        printf("Lỗi khi ghi vào tệp!\n");
    }
    
    // Đọc nội dung từ tệp nhị phân để kiểm tra
    DocFile("data.out");
    
    return 0;
}
