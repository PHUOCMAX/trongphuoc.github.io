#include <stdio.h>
#include <stdlib.h>

// Cấu trúc nút trong cây BST
struct BST_NODE {
    int Key;       // Khóa của nút
    int So_lan;    // Số lần xuất hiện
    struct BST_NODE *Left, *Right;
};

// Cấu trúc cây BST
struct BST_TREE {
    struct BST_NODE *pRoot; // Nút gốc của cây
};

// Hàm tạo một nút mới
BST_NODE* CreateNode(int key) {
    BST_NODE* newNode = (BST_NODE*)malloc(sizeof(BST_NODE));
    newNode->Key = key;
    newNode->So_lan = 1;
    newNode->Left = newNode->Right = NULL;
    return newNode;
}

// Hàm chèn một phần tử vào cây
void InsertNode(BST_TREE &t, int key) {
    BST_NODE **p = &t.pRoot;
    while (*p) {
        if ((*p)->Key == key) {
            (*p)->So_lan++; // Nếu khóa đã tồn tại, tăng số lần xuất hiện
            return;
        }
        p = (key < (*p)->Key) ? &(*p)->Left : &(*p)->Right;
    }
    *p = CreateNode(key);
}

// Hàm tìm và xóa một giá trị trong cây
int DeleteNode(BST_NODE* Root, int x) {
    if (Root == NULL)
        return 0;
    if (Root->Key == x) {
        if (Root->So_lan > 0) {
            Root->So_lan--; // Giảm số lần xuất hiện
            return 1;
        }
        return 0;
    }
    if (x < Root->Key)
        return DeleteNode(Root->Left, x);
    return DeleteNode(Root->Right, x);
}

// Hàm gọi xóa và in thông báo
void XoaGiaTri(BST_TREE &t, int x) {
    int kq = DeleteNode(t.pRoot, x);
    if (kq == 0)
        printf("Khong ton tai X\n");
    else
        printf("Xoa thanh cong.\n");
}

// Hàm duyệt cây theo thứ tự NLR
void NLR(BST_NODE* Root) {
    if (Root == NULL)
        return;
    if (Root->So_lan > 0)
        printf("%4d", Root->Key);
    NLR(Root->Left);
    NLR(Root->Right);
}

// Hàm in các phần tử của cây
void LietKe(BST_TREE t) {
    NLR(t.pRoot);
    printf("\n");
}

int main() {
    BST_TREE t;
    t.pRoot = NULL;

    // Chèn một số phần tử vào cây
    InsertNode(t, 50);
    InsertNode(t, 30);
    InsertNode(t, 70);
    InsertNode(t, 20);
    InsertNode(t, 40);
    InsertNode(t, 80);
    InsertNode(t, 50); // Tăng số lần xuất hiện của 50

    printf("Cay BST theo thu tu NLR:\n");
    LietKe(t);

    printf("\nXoa 50:\n");
    XoaGiaTri(t, 50);
    LietKe(t);

    printf("\nXoa 50 tiep tuc:\n");
    XoaGiaTri(t, 50);
    LietKe(t);
    
    return 0;
}
