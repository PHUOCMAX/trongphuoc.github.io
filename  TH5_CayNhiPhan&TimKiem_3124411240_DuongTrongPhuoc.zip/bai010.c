#include <stdio.h>
#include <stdlib.h>

// Định nghĩa cấu trúc cây nhị phân
struct node {
    float info;
    struct node *pLeft;
    struct node *pRight;
};
typedef struct node NODE;
typedef NODE* TREE;

// Hàm chèn phần tử vào cây nhị phân tìm kiếm
void InsertNode(TREE *t, float x) {
    if (*t == NULL) {
        NODE *newNode = (NODE *)malloc(sizeof(NODE));
        newNode->info = x;
        newNode->pLeft = NULL;
        newNode->pRight = NULL;
        *t = newNode;
    } else {
        if (x < (*t)->info)
            InsertNode(&((*t)->pLeft), x);
        else
            InsertNode(&((*t)->pRight), x);
    }
}

// Hàm duyệt cây theo thứ tự LRN và ghi vào tệp
void LRN(TREE t, FILE *fp) {
    if (t == NULL)
        return;
    LRN(t->pLeft, fp);     // Duyệt cây con trái
    LRN(t->pRight, fp);    // Duyệt cây con phải
    fwrite(&t->info, sizeof(float), 1, fp);  // Ghi giá trị vào tệp
}

// Hàm ghi dữ liệu vào tệp nhị phân
int Xuat(char *filename, TREE t) {
    FILE *fp = fopen(filename, "wb");  // Mở tệp ở chế độ ghi nhị phân
    if (fp == NULL)
        return 0; // Lỗi mở tệp
    LRN(t, fp);   // Gọi hàm duyệt LRN để ghi dữ liệu vào tệp
    fclose(fp);   // Đóng tệp
    return 1;     // Trả về 1 nếu thành công
}

// Hàm đọc dữ liệu từ tệp nhị phân
void DocFile(char *filename) {
    FILE *fp = fopen(filename, "rb");  // Mở tệp ở chế độ đọc nhị phân
    if (fp == NULL) {
        printf("Không thể mở tệp!\n");
        return;
    }
    float value;
    printf("Dữ liệu trong tệp: ");
    while (fread(&value, sizeof(float), 1, fp)) {
        printf("%.2f ", value);
    }
    printf("\n");
    fclose(fp);
}

int main() {
    TREE t = NULL;
    
    // Chèn các phần tử vào cây
    InsertNode(&t, 10.5);
    InsertNode(&t, 5.2);
    InsertNode(&t, 15.8);
    InsertNode(&t, 3.1);
    InsertNode(&t, 7.7);
    InsertNode(&t, 12.4);
    InsertNode(&t, 20.9);
    
    // Xuất cây vào tệp theo thứ tự LRN
    if (Xuat("data.out", t)) {
        printf("Ghi thành công vào data.out!\n");
    } else {
        printf("Lỗi khi ghi vào tệp!\n");
    }
    
    // Đọc nội dung từ tệp nhị phân để kiểm tra
    DocFile("data.out");
    
    return 0;
}
