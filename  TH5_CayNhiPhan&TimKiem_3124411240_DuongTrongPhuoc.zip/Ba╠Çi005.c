#include <stdio.h>
#include <stdlib.h>

// Cấu trúc một nút trong cây nhị phân tìm kiếm
typedef struct TreeNode {
    int val;
    struct TreeNode* left;
    struct TreeNode* right;
} TreeNode;

// Hàm tạo một nút mới
TreeNode* createNode(int val) {
    TreeNode* newNode = (TreeNode*)malloc(sizeof(TreeNode));
    newNode->val = val;
    newNode->left = newNode->right = NULL;
    return newNode;
}

// Hàm chèn một nút vào cây nhị phân tìm kiếm
TreeNode* insert(TreeNode* root, int val) {
    if (root == NULL) return createNode(val);
    if (val < root->val)
        root->left = insert(root->left, val);
    else
        root->right = insert(root->right, val);
    return root;
}

// Hàm duyệt tiền tự (NLR)
void preorderTraversal(TreeNode* root) {
    if (root == NULL) return;
    printf("%d ", root->val);
    preorderTraversal(root->left);
    preorderTraversal(root->right);
}

// Hàm đệ quy đếm số nút có một con
int countOneChildNodes(TreeNode* root) {
    if (root == NULL) return 0;
    if ((root->left && !root->right) || (!root->left && root->right))
        return 1 + countOneChildNodes(root->left) + countOneChildNodes(root->right);
    return countOneChildNodes(root->left) + countOneChildNodes(root->right);
}

int main() {
    // Xây dựng cây với thứ tự chèn: 10, 5, 15, 3, 9, 12, 18, 7, 20
    TreeNode* root = NULL;
    int values[] = {10, 5, 15, 3, 9, 12, 18, 7, 20};
    int n = sizeof(values) / sizeof(values[0]);
    for (int i = 0; i < n; i++) {
        root = insert(root, values[i]);
    }

    // In kết quả duyệt tiền tự
    printf("Duyệt tiền tự (Preorder NLR): ");
    preorderTraversal(root);
    printf("\n");
    
    // Đếm số nút có một con
    int oneChildNodes = countOneChildNodes(root);
    printf("Số nút có một con: %d\n", oneChildNodes);
    
    return 0;
}
