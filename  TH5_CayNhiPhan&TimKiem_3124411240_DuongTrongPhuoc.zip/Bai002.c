#include <stdio.h>
#include <stdlib.h>

typedef struct TreeNode {
    int val;
    struct TreeNode* left;
    struct TreeNode* right;
} TreeNode;

TreeNode* createNode(int val) {
    TreeNode* newNode = (TreeNode*)malloc(sizeof(TreeNode));
    newNode->val = val;
    newNode->left = newNode->right = NULL;
    return newNode;
}

void swapTreeStructure(TreeNode* p) {
    if (!p || !p->left || !p->right) return;
    
    // Bước 1 - 3: Hoán đổi con trái và con phải của p
    TreeNode* temp = p->left;
    p->left = p->right;
    p->right = temp;
    
    // Bước 4 - 6: Hoán đổi con trái và con phải của p->left
    temp = p->left->left;
    p->left->left = p->left->right;
    p->left->right = temp;
}

void inorderTraversal(TreeNode* root) {
    if (root == NULL) return;
    inorderTraversal(root->left);
    printf("%d ", root->val);
    inorderTraversal(root->right);
}

int main() {
    TreeNode* root = createNode(1);
    root->left = createNode(2);
    root->right = createNode(3);
    root->left->left = createNode(4);
    root->left->right = createNode(5);
    
    printf("Cay truoc khi hoan doi:\n");
    inorderTraversal(root);
    printf("\n");
    
    swapTreeStructure(root);
    
    printf("Cay sau khi hoan doi:\n");
    inorderTraversal(root);
    printf("\n");
    
    return 0;
}